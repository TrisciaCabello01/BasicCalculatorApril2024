﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim CustomizableEdges51 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges52 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges49 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges50 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges9 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges10 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges11 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges12 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges13 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges14 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges15 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges16 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges17 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges18 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges19 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges20 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges21 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges22 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges23 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges24 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges25 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges26 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges27 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges28 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges29 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges30 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges31 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges32 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges33 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges34 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges35 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges36 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges37 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges38 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges39 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges40 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges41 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges42 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges43 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges44 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges45 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges46 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges47 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges48 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(components)
        Panel1 = New Panel()
        IconButton2 = New FontAwesome.Sharp.IconButton()
        Label1 = New Label()
        buttonMinimize = New FontAwesome.Sharp.IconButton()
        IconButton1 = New FontAwesome.Sharp.IconButton()
        Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        buttonHistory = New FontAwesome.Sharp.IconButton()
        txtDisplay2 = New TextBox()
        txtDisplay1 = New TextBox()
        Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        buttonEquals = New Guna.UI2.WinForms.Guna2Button()
        buttonThousand = New Guna.UI2.WinForms.Guna2Button()
        button0 = New Guna.UI2.WinForms.Guna2Button()
        buttonDecimal = New Guna.UI2.WinForms.Guna2Button()
        buttonAddition = New Guna.UI2.WinForms.Guna2Button()
        buttonSubtraction = New Guna.UI2.WinForms.Guna2Button()
        buttonMultiplication = New Guna.UI2.WinForms.Guna2Button()
        button1 = New Guna.UI2.WinForms.Guna2Button()
        button2 = New Guna.UI2.WinForms.Guna2Button()
        button3 = New Guna.UI2.WinForms.Guna2Button()
        button4 = New Guna.UI2.WinForms.Guna2Button()
        button5 = New Guna.UI2.WinForms.Guna2Button()
        button6 = New Guna.UI2.WinForms.Guna2Button()
        button7 = New Guna.UI2.WinForms.Guna2Button()
        button8 = New Guna.UI2.WinForms.Guna2Button()
        button1overX = New Guna.UI2.WinForms.Guna2Button()
        buttonDivision = New Guna.UI2.WinForms.Guna2Button()
        button9 = New Guna.UI2.WinForms.Guna2Button()
        buttonSquared = New Guna.UI2.WinForms.Guna2Button()
        buttonSquareRoot = New Guna.UI2.WinForms.Guna2Button()
        buttonPercentage = New Guna.UI2.WinForms.Guna2Button()
        buttonCE = New Guna.UI2.WinForms.Guna2Button()
        buttonC = New Guna.UI2.WinForms.Guna2Button()
        buttonDelete = New Guna.UI2.WinForms.Guna2Button()
        historyPanel = New Panel()
        RichTextBox1 = New RichTextBox()
        buttonClearHistory = New FontAwesome.Sharp.IconButton()
        Panel1.SuspendLayout()
        Guna2Panel1.SuspendLayout()
        Guna2CustomGradientPanel1.SuspendLayout()
        historyPanel.SuspendLayout()
        SuspendLayout()
        ' 
        ' Guna2Elipse1
        ' 
        Guna2Elipse1.BorderRadius = 20
        Guna2Elipse1.TargetControl = Me
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(IconButton2)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(buttonMinimize)
        Panel1.Controls.Add(IconButton1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(380, 38)
        Panel1.TabIndex = 0
        ' 
        ' IconButton2
        ' 
        IconButton2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        IconButton2.Cursor = Cursors.Hand
        IconButton2.FlatAppearance.BorderSize = 0
        IconButton2.FlatStyle = FlatStyle.Flat
        IconButton2.ForeColor = Color.White
        IconButton2.IconChar = FontAwesome.Sharp.IconChar.Calculator
        IconButton2.IconColor = Color.White
        IconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto
        IconButton2.IconSize = 23
        IconButton2.Location = New Point(3, 5)
        IconButton2.Name = "IconButton2"
        IconButton2.Size = New Size(34, 29)
        IconButton2.TabIndex = 3
        IconButton2.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Stencil", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(43, 12)
        Label1.Name = "Label1"
        Label1.Size = New Size(164, 16)
        Label1.TabIndex = 2
        Label1.Text = "Calculator Ni Bulatao"
        ' 
        ' buttonMinimize
        ' 
        buttonMinimize.Cursor = Cursors.Hand
        buttonMinimize.Dock = DockStyle.Right
        buttonMinimize.FlatAppearance.BorderSize = 0
        buttonMinimize.FlatStyle = FlatStyle.Flat
        buttonMinimize.ForeColor = Color.White
        buttonMinimize.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize
        buttonMinimize.IconColor = Color.White
        buttonMinimize.IconFont = FontAwesome.Sharp.IconFont.Auto
        buttonMinimize.IconSize = 28
        buttonMinimize.Location = New Point(288, 0)
        buttonMinimize.Name = "buttonMinimize"
        buttonMinimize.Size = New Size(46, 38)
        buttonMinimize.TabIndex = 1
        buttonMinimize.UseVisualStyleBackColor = True
        ' 
        ' IconButton1
        ' 
        IconButton1.Cursor = Cursors.Hand
        IconButton1.Dock = DockStyle.Right
        IconButton1.FlatAppearance.BorderSize = 0
        IconButton1.FlatStyle = FlatStyle.Flat
        IconButton1.ForeColor = Color.White
        IconButton1.IconChar = FontAwesome.Sharp.IconChar.X
        IconButton1.IconColor = Color.White
        IconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto
        IconButton1.IconSize = 22
        IconButton1.Location = New Point(334, 0)
        IconButton1.Name = "IconButton1"
        IconButton1.Size = New Size(46, 38)
        IconButton1.TabIndex = 0
        IconButton1.UseVisualStyleBackColor = True
        ' 
        ' Guna2Panel1
        ' 
        Guna2Panel1.Controls.Add(buttonHistory)
        Guna2Panel1.CustomizableEdges = CustomizableEdges51
        Guna2Panel1.Dock = DockStyle.Top
        Guna2Panel1.Location = New Point(0, 38)
        Guna2Panel1.Name = "Guna2Panel1"
        Guna2Panel1.ShadowDecoration.CustomizableEdges = CustomizableEdges52
        Guna2Panel1.Size = New Size(380, 47)
        Guna2Panel1.TabIndex = 1
        ' 
        ' buttonHistory
        ' 
        buttonHistory.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        buttonHistory.Cursor = Cursors.Hand
        buttonHistory.FlatAppearance.BorderSize = 0
        buttonHistory.FlatStyle = FlatStyle.Flat
        buttonHistory.ForeColor = Color.White
        buttonHistory.IconChar = FontAwesome.Sharp.IconChar.ClockRotateLeft
        buttonHistory.IconColor = Color.White
        buttonHistory.IconFont = FontAwesome.Sharp.IconFont.Auto
        buttonHistory.IconSize = 28
        buttonHistory.Location = New Point(331, 5)
        buttonHistory.Name = "buttonHistory"
        buttonHistory.Size = New Size(46, 38)
        buttonHistory.TabIndex = 2
        buttonHistory.UseVisualStyleBackColor = True
        ' 
        ' txtDisplay2
        ' 
        txtDisplay2.BackColor = Color.FromArgb(CByte(32), CByte(32), CByte(32))
        txtDisplay2.BorderStyle = BorderStyle.None
        txtDisplay2.Dock = DockStyle.Top
        txtDisplay2.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtDisplay2.ForeColor = Color.DarkGray
        txtDisplay2.Location = New Point(0, 85)
        txtDisplay2.Margin = New Padding(0)
        txtDisplay2.Multiline = True
        txtDisplay2.Name = "txtDisplay2"
        txtDisplay2.ReadOnly = True
        txtDisplay2.Size = New Size(380, 25)
        txtDisplay2.TabIndex = 2
        txtDisplay2.TextAlign = HorizontalAlignment.Right
        ' 
        ' txtDisplay1
        ' 
        txtDisplay1.BackColor = Color.FromArgb(CByte(32), CByte(32), CByte(32))
        txtDisplay1.BorderStyle = BorderStyle.None
        txtDisplay1.Dock = DockStyle.Top
        txtDisplay1.Font = New Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtDisplay1.ForeColor = Color.White
        txtDisplay1.Location = New Point(0, 110)
        txtDisplay1.Margin = New Padding(0)
        txtDisplay1.Multiline = True
        txtDisplay1.Name = "txtDisplay1"
        txtDisplay1.ReadOnly = True
        txtDisplay1.Size = New Size(380, 78)
        txtDisplay1.TabIndex = 3
        txtDisplay1.Text = "0"
        txtDisplay1.TextAlign = HorizontalAlignment.Right
        ' 
        ' Guna2CustomGradientPanel1
        ' 
        Guna2CustomGradientPanel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Guna2CustomGradientPanel1.BorderRadius = 20
        Guna2CustomGradientPanel1.Controls.Add(buttonEquals)
        Guna2CustomGradientPanel1.Controls.Add(buttonThousand)
        Guna2CustomGradientPanel1.Controls.Add(button0)
        Guna2CustomGradientPanel1.Controls.Add(buttonDecimal)
        Guna2CustomGradientPanel1.Controls.Add(buttonAddition)
        Guna2CustomGradientPanel1.Controls.Add(buttonSubtraction)
        Guna2CustomGradientPanel1.Controls.Add(buttonMultiplication)
        Guna2CustomGradientPanel1.Controls.Add(button1)
        Guna2CustomGradientPanel1.Controls.Add(button2)
        Guna2CustomGradientPanel1.Controls.Add(button3)
        Guna2CustomGradientPanel1.Controls.Add(button4)
        Guna2CustomGradientPanel1.Controls.Add(button5)
        Guna2CustomGradientPanel1.Controls.Add(button6)
        Guna2CustomGradientPanel1.Controls.Add(button7)
        Guna2CustomGradientPanel1.Controls.Add(button8)
        Guna2CustomGradientPanel1.Controls.Add(button1overX)
        Guna2CustomGradientPanel1.Controls.Add(buttonDivision)
        Guna2CustomGradientPanel1.Controls.Add(button9)
        Guna2CustomGradientPanel1.Controls.Add(buttonSquared)
        Guna2CustomGradientPanel1.Controls.Add(buttonSquareRoot)
        Guna2CustomGradientPanel1.Controls.Add(buttonPercentage)
        Guna2CustomGradientPanel1.Controls.Add(buttonCE)
        Guna2CustomGradientPanel1.Controls.Add(buttonC)
        Guna2CustomGradientPanel1.Controls.Add(buttonDelete)
        Guna2CustomGradientPanel1.CustomizableEdges = CustomizableEdges49
        Guna2CustomGradientPanel1.FillColor = Color.FromArgb(CByte(50), CByte(50), CByte(50))
        Guna2CustomGradientPanel1.FillColor2 = Color.FromArgb(CByte(50), CByte(50), CByte(50))
        Guna2CustomGradientPanel1.FillColor3 = Color.FromArgb(CByte(50), CByte(50), CByte(50))
        Guna2CustomGradientPanel1.FillColor4 = Color.FromArgb(CByte(50), CByte(50), CByte(50))
        Guna2CustomGradientPanel1.Location = New Point(12, 191)
        Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = CustomizableEdges50
        Guna2CustomGradientPanel1.Size = New Size(356, 354)
        Guna2CustomGradientPanel1.TabIndex = 4
        ' 
        ' buttonEquals
        ' 
        buttonEquals.BackColor = Color.Transparent
        buttonEquals.BorderRadius = 10
        buttonEquals.CustomizableEdges = CustomizableEdges1
        buttonEquals.DisabledState.BorderColor = Color.DarkGray
        buttonEquals.DisabledState.CustomBorderColor = Color.DarkGray
        buttonEquals.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonEquals.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonEquals.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonEquals.Font = New Font("Segoe UI", 15.75F)
        buttonEquals.ForeColor = Color.White
        buttonEquals.Image = My.Resources.Resources.icons8_equals_67
        buttonEquals.ImageSize = New Size(45, 45)
        buttonEquals.Location = New Point(265, 295)
        buttonEquals.Name = "buttonEquals"
        buttonEquals.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        buttonEquals.Size = New Size(79, 49)
        buttonEquals.TabIndex = 23
        ' 
        ' buttonThousand
        ' 
        buttonThousand.BackColor = Color.Transparent
        buttonThousand.BorderRadius = 10
        buttonThousand.CustomizableEdges = CustomizableEdges3
        buttonThousand.DisabledState.BorderColor = Color.DarkGray
        buttonThousand.DisabledState.CustomBorderColor = Color.DarkGray
        buttonThousand.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonThousand.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonThousand.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonThousand.Font = New Font("Segoe UI", 15.75F)
        buttonThousand.ForeColor = Color.White
        buttonThousand.ImageSize = New Size(35, 35)
        buttonThousand.Location = New Point(10, 295)
        buttonThousand.Name = "buttonThousand"
        buttonThousand.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        buttonThousand.Size = New Size(79, 49)
        buttonThousand.TabIndex = 22
        buttonThousand.Text = "..."
        ' 
        ' button0
        ' 
        button0.BackColor = Color.Transparent
        button0.BorderRadius = 10
        button0.CustomizableEdges = CustomizableEdges5
        button0.DisabledState.BorderColor = Color.DarkGray
        button0.DisabledState.CustomBorderColor = Color.DarkGray
        button0.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button0.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button0.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button0.Font = New Font("Segoe UI", 15.75F)
        button0.ForeColor = Color.White
        button0.ImageSize = New Size(35, 35)
        button0.Location = New Point(95, 295)
        button0.Name = "button0"
        button0.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        button0.Size = New Size(79, 49)
        button0.TabIndex = 21
        button0.Text = "0"
        ' 
        ' buttonDecimal
        ' 
        buttonDecimal.BackColor = Color.Transparent
        buttonDecimal.BorderRadius = 10
        buttonDecimal.CustomizableEdges = CustomizableEdges7
        buttonDecimal.DisabledState.BorderColor = Color.DarkGray
        buttonDecimal.DisabledState.CustomBorderColor = Color.DarkGray
        buttonDecimal.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonDecimal.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonDecimal.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonDecimal.Font = New Font("Segoe UI", 15.75F)
        buttonDecimal.ForeColor = Color.White
        buttonDecimal.ImageSize = New Size(15, 15)
        buttonDecimal.Location = New Point(180, 295)
        buttonDecimal.Name = "buttonDecimal"
        buttonDecimal.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        buttonDecimal.Size = New Size(79, 49)
        buttonDecimal.TabIndex = 20
        buttonDecimal.Text = "."
        ' 
        ' buttonAddition
        ' 
        buttonAddition.BackColor = Color.Transparent
        buttonAddition.BorderRadius = 10
        buttonAddition.CustomizableEdges = CustomizableEdges9
        buttonAddition.DisabledState.BorderColor = Color.DarkGray
        buttonAddition.DisabledState.CustomBorderColor = Color.DarkGray
        buttonAddition.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonAddition.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonAddition.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonAddition.Font = New Font("Segoe UI", 1.5F)
        buttonAddition.ForeColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonAddition.Image = My.Resources.Resources.icons8_addition_50
        buttonAddition.ImageSize = New Size(45, 45)
        buttonAddition.Location = New Point(265, 240)
        buttonAddition.Name = "buttonAddition"
        buttonAddition.ShadowDecoration.CustomizableEdges = CustomizableEdges10
        buttonAddition.Size = New Size(79, 49)
        buttonAddition.TabIndex = 19
        buttonAddition.Text = "+"
        ' 
        ' buttonSubtraction
        ' 
        buttonSubtraction.BackColor = Color.Transparent
        buttonSubtraction.BorderRadius = 10
        buttonSubtraction.CustomizableEdges = CustomizableEdges11
        buttonSubtraction.DisabledState.BorderColor = Color.DarkGray
        buttonSubtraction.DisabledState.CustomBorderColor = Color.DarkGray
        buttonSubtraction.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonSubtraction.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonSubtraction.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonSubtraction.Font = New Font("Segoe UI", 1.5F)
        buttonSubtraction.ForeColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonSubtraction.Image = My.Resources.Resources.icons8_minus_48
        buttonSubtraction.ImageSize = New Size(35, 35)
        buttonSubtraction.Location = New Point(265, 185)
        buttonSubtraction.Name = "buttonSubtraction"
        buttonSubtraction.ShadowDecoration.CustomizableEdges = CustomizableEdges12
        buttonSubtraction.Size = New Size(79, 49)
        buttonSubtraction.TabIndex = 18
        buttonSubtraction.Text = "-"
        ' 
        ' buttonMultiplication
        ' 
        buttonMultiplication.BackColor = Color.Transparent
        buttonMultiplication.BorderRadius = 10
        buttonMultiplication.CustomizableEdges = CustomizableEdges13
        buttonMultiplication.DisabledState.BorderColor = Color.DarkGray
        buttonMultiplication.DisabledState.CustomBorderColor = Color.DarkGray
        buttonMultiplication.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonMultiplication.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonMultiplication.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonMultiplication.Font = New Font("Segoe UI", 1.5F)
        buttonMultiplication.ForeColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonMultiplication.Image = My.Resources.Resources.icons8_multiply_48
        buttonMultiplication.ImageSize = New Size(28, 28)
        buttonMultiplication.Location = New Point(265, 130)
        buttonMultiplication.Name = "buttonMultiplication"
        buttonMultiplication.ShadowDecoration.CustomizableEdges = CustomizableEdges14
        buttonMultiplication.Size = New Size(79, 49)
        buttonMultiplication.TabIndex = 17
        buttonMultiplication.Text = "*"
        ' 
        ' button1
        ' 
        button1.BackColor = Color.Transparent
        button1.BorderRadius = 10
        button1.CustomizableEdges = CustomizableEdges15
        button1.DisabledState.BorderColor = Color.DarkGray
        button1.DisabledState.CustomBorderColor = Color.DarkGray
        button1.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button1.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button1.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button1.Font = New Font("Segoe UI", 15.75F)
        button1.ForeColor = Color.White
        button1.ImageSize = New Size(35, 35)
        button1.Location = New Point(10, 240)
        button1.Name = "button1"
        button1.ShadowDecoration.CustomizableEdges = CustomizableEdges16
        button1.Size = New Size(79, 49)
        button1.TabIndex = 16
        button1.Text = "1"
        ' 
        ' button2
        ' 
        button2.BackColor = Color.Transparent
        button2.BorderRadius = 10
        button2.CustomizableEdges = CustomizableEdges17
        button2.DisabledState.BorderColor = Color.DarkGray
        button2.DisabledState.CustomBorderColor = Color.DarkGray
        button2.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button2.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button2.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button2.Font = New Font("Segoe UI", 15.75F)
        button2.ForeColor = Color.White
        button2.ImageSize = New Size(35, 35)
        button2.Location = New Point(95, 240)
        button2.Name = "button2"
        button2.ShadowDecoration.CustomizableEdges = CustomizableEdges18
        button2.Size = New Size(79, 49)
        button2.TabIndex = 15
        button2.Text = "2"
        ' 
        ' button3
        ' 
        button3.BackColor = Color.Transparent
        button3.BorderRadius = 10
        button3.CustomizableEdges = CustomizableEdges19
        button3.DisabledState.BorderColor = Color.DarkGray
        button3.DisabledState.CustomBorderColor = Color.DarkGray
        button3.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button3.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button3.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button3.Font = New Font("Segoe UI", 15.75F)
        button3.ForeColor = Color.White
        button3.ImageSize = New Size(35, 35)
        button3.Location = New Point(180, 240)
        button3.Name = "button3"
        button3.ShadowDecoration.CustomizableEdges = CustomizableEdges20
        button3.Size = New Size(79, 49)
        button3.TabIndex = 14
        button3.Text = "3"
        ' 
        ' button4
        ' 
        button4.BackColor = Color.Transparent
        button4.BorderRadius = 10
        button4.CustomizableEdges = CustomizableEdges21
        button4.DisabledState.BorderColor = Color.DarkGray
        button4.DisabledState.CustomBorderColor = Color.DarkGray
        button4.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button4.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button4.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button4.Font = New Font("Segoe UI", 15.75F)
        button4.ForeColor = Color.White
        button4.ImageSize = New Size(35, 35)
        button4.Location = New Point(10, 185)
        button4.Name = "button4"
        button4.ShadowDecoration.CustomizableEdges = CustomizableEdges22
        button4.Size = New Size(79, 49)
        button4.TabIndex = 13
        button4.Text = "4"
        ' 
        ' button5
        ' 
        button5.BackColor = Color.Transparent
        button5.BorderRadius = 10
        button5.CustomizableEdges = CustomizableEdges23
        button5.DisabledState.BorderColor = Color.DarkGray
        button5.DisabledState.CustomBorderColor = Color.DarkGray
        button5.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button5.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button5.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button5.Font = New Font("Segoe UI", 15.75F)
        button5.ForeColor = Color.White
        button5.ImageSize = New Size(35, 35)
        button5.Location = New Point(95, 185)
        button5.Name = "button5"
        button5.ShadowDecoration.CustomizableEdges = CustomizableEdges24
        button5.Size = New Size(79, 49)
        button5.TabIndex = 12
        button5.Text = "5"
        ' 
        ' button6
        ' 
        button6.BackColor = Color.Transparent
        button6.BorderRadius = 10
        button6.CustomizableEdges = CustomizableEdges25
        button6.DisabledState.BorderColor = Color.DarkGray
        button6.DisabledState.CustomBorderColor = Color.DarkGray
        button6.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button6.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button6.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button6.Font = New Font("Segoe UI", 15.75F)
        button6.ForeColor = Color.White
        button6.ImageSize = New Size(35, 35)
        button6.Location = New Point(180, 185)
        button6.Name = "button6"
        button6.ShadowDecoration.CustomizableEdges = CustomizableEdges26
        button6.Size = New Size(79, 49)
        button6.TabIndex = 11
        button6.Text = "6"
        ' 
        ' button7
        ' 
        button7.BackColor = Color.Transparent
        button7.BorderRadius = 10
        button7.CustomizableEdges = CustomizableEdges27
        button7.DisabledState.BorderColor = Color.DarkGray
        button7.DisabledState.CustomBorderColor = Color.DarkGray
        button7.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button7.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button7.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button7.Font = New Font("Segoe UI", 15.75F)
        button7.ForeColor = Color.White
        button7.ImageSize = New Size(35, 35)
        button7.Location = New Point(10, 130)
        button7.Name = "button7"
        button7.ShadowDecoration.CustomizableEdges = CustomizableEdges28
        button7.Size = New Size(79, 49)
        button7.TabIndex = 10
        button7.Text = "7"
        ' 
        ' button8
        ' 
        button8.BackColor = Color.Transparent
        button8.BorderRadius = 10
        button8.CustomizableEdges = CustomizableEdges29
        button8.DisabledState.BorderColor = Color.DarkGray
        button8.DisabledState.CustomBorderColor = Color.DarkGray
        button8.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button8.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button8.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button8.Font = New Font("Segoe UI", 15.75F)
        button8.ForeColor = Color.White
        button8.ImageSize = New Size(35, 35)
        button8.Location = New Point(95, 130)
        button8.Name = "button8"
        button8.ShadowDecoration.CustomizableEdges = CustomizableEdges30
        button8.Size = New Size(79, 49)
        button8.TabIndex = 9
        button8.Text = "8"
        ' 
        ' button1overX
        ' 
        button1overX.BackColor = Color.Transparent
        button1overX.BorderRadius = 10
        button1overX.CustomizableEdges = CustomizableEdges31
        button1overX.DisabledState.BorderColor = Color.DarkGray
        button1overX.DisabledState.CustomBorderColor = Color.DarkGray
        button1overX.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button1overX.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button1overX.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        button1overX.Font = New Font("Segoe UI", 15.75F)
        button1overX.ForeColor = Color.White
        button1overX.ImageSize = New Size(45, 45)
        button1overX.Location = New Point(10, 75)
        button1overX.Name = "button1overX"
        button1overX.ShadowDecoration.CustomizableEdges = CustomizableEdges32
        button1overX.Size = New Size(79, 49)
        button1overX.TabIndex = 8
        button1overX.Text = "1/x"
        ' 
        ' buttonDivision
        ' 
        buttonDivision.BackColor = Color.Transparent
        buttonDivision.BorderRadius = 10
        buttonDivision.CustomizableEdges = CustomizableEdges33
        buttonDivision.DisabledState.BorderColor = Color.DarkGray
        buttonDivision.DisabledState.CustomBorderColor = Color.DarkGray
        buttonDivision.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonDivision.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonDivision.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonDivision.Font = New Font("Segoe UI", 1.5F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        buttonDivision.ForeColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        buttonDivision.Image = My.Resources.Resources.divide2
        buttonDivision.ImageSize = New Size(35, 35)
        buttonDivision.Location = New Point(265, 75)
        buttonDivision.Name = "buttonDivision"
        buttonDivision.ShadowDecoration.CustomizableEdges = CustomizableEdges34
        buttonDivision.Size = New Size(79, 49)
        buttonDivision.TabIndex = 7
        buttonDivision.Text = "/"
        ' 
        ' button9
        ' 
        button9.BackColor = Color.Transparent
        button9.BorderRadius = 10
        button9.CustomizableEdges = CustomizableEdges35
        button9.DisabledState.BorderColor = Color.DarkGray
        button9.DisabledState.CustomBorderColor = Color.DarkGray
        button9.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        button9.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        button9.FillColor = Color.FromArgb(CByte(80), CByte(80), CByte(80))
        button9.Font = New Font("Segoe UI", 15.75F)
        button9.ForeColor = Color.White
        button9.ImageSize = New Size(35, 35)
        button9.Location = New Point(180, 130)
        button9.Name = "button9"
        button9.ShadowDecoration.CustomizableEdges = CustomizableEdges36
        button9.Size = New Size(79, 49)
        button9.TabIndex = 6
        button9.Text = "9"
        ' 
        ' buttonSquared
        ' 
        buttonSquared.BackColor = Color.Transparent
        buttonSquared.BorderRadius = 10
        buttonSquared.CustomizableEdges = CustomizableEdges37
        buttonSquared.DisabledState.BorderColor = Color.DarkGray
        buttonSquared.DisabledState.CustomBorderColor = Color.DarkGray
        buttonSquared.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonSquared.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonSquared.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonSquared.Font = New Font("Segoe UI", 15.75F)
        buttonSquared.ForeColor = Color.White
        buttonSquared.ImageSize = New Size(45, 45)
        buttonSquared.Location = New Point(95, 75)
        buttonSquared.Name = "buttonSquared"
        buttonSquared.ShadowDecoration.CustomizableEdges = CustomizableEdges38
        buttonSquared.Size = New Size(79, 49)
        buttonSquared.TabIndex = 5
        buttonSquared.Text = "x^2"
        ' 
        ' buttonSquareRoot
        ' 
        buttonSquareRoot.BackColor = Color.Transparent
        buttonSquareRoot.BorderRadius = 10
        buttonSquareRoot.CustomizableEdges = CustomizableEdges39
        buttonSquareRoot.DisabledState.BorderColor = Color.DarkGray
        buttonSquareRoot.DisabledState.CustomBorderColor = Color.DarkGray
        buttonSquareRoot.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonSquareRoot.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonSquareRoot.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonSquareRoot.Font = New Font("Segoe UI", 15.75F)
        buttonSquareRoot.ForeColor = Color.White
        buttonSquareRoot.Image = My.Resources.Resources.squareroot
        buttonSquareRoot.ImageSize = New Size(35, 35)
        buttonSquareRoot.Location = New Point(180, 75)
        buttonSquareRoot.Name = "buttonSquareRoot"
        buttonSquareRoot.ShadowDecoration.CustomizableEdges = CustomizableEdges40
        buttonSquareRoot.Size = New Size(79, 49)
        buttonSquareRoot.TabIndex = 4
        ' 
        ' buttonPercentage
        ' 
        buttonPercentage.BackColor = Color.Transparent
        buttonPercentage.BorderRadius = 10
        buttonPercentage.CustomizableEdges = CustomizableEdges41
        buttonPercentage.DisabledState.BorderColor = Color.DarkGray
        buttonPercentage.DisabledState.CustomBorderColor = Color.DarkGray
        buttonPercentage.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonPercentage.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonPercentage.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonPercentage.Font = New Font("Segoe UI", 9F)
        buttonPercentage.ForeColor = Color.White
        buttonPercentage.Image = My.Resources.Resources.percent
        buttonPercentage.ImageSize = New Size(35, 35)
        buttonPercentage.Location = New Point(10, 20)
        buttonPercentage.Name = "buttonPercentage"
        buttonPercentage.ShadowDecoration.CustomizableEdges = CustomizableEdges42
        buttonPercentage.Size = New Size(79, 49)
        buttonPercentage.TabIndex = 3
        ' 
        ' buttonCE
        ' 
        buttonCE.BackColor = Color.Transparent
        buttonCE.BorderRadius = 10
        buttonCE.CustomizableEdges = CustomizableEdges43
        buttonCE.DisabledState.BorderColor = Color.DarkGray
        buttonCE.DisabledState.CustomBorderColor = Color.DarkGray
        buttonCE.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonCE.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonCE.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonCE.Font = New Font("Segoe UI", 15.75F)
        buttonCE.ForeColor = Color.White
        buttonCE.ImageSize = New Size(45, 45)
        buttonCE.Location = New Point(95, 20)
        buttonCE.Name = "buttonCE"
        buttonCE.ShadowDecoration.CustomizableEdges = CustomizableEdges44
        buttonCE.Size = New Size(79, 49)
        buttonCE.TabIndex = 2
        buttonCE.Text = "CE"
        ' 
        ' buttonC
        ' 
        buttonC.BackColor = Color.Transparent
        buttonC.BorderRadius = 10
        buttonC.CustomizableEdges = CustomizableEdges45
        buttonC.DisabledState.BorderColor = Color.DarkGray
        buttonC.DisabledState.CustomBorderColor = Color.DarkGray
        buttonC.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonC.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonC.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonC.Font = New Font("Segoe UI", 15.75F)
        buttonC.ForeColor = Color.White
        buttonC.ImageSize = New Size(35, 35)
        buttonC.Location = New Point(180, 20)
        buttonC.Name = "buttonC"
        buttonC.ShadowDecoration.CustomizableEdges = CustomizableEdges46
        buttonC.Size = New Size(79, 49)
        buttonC.TabIndex = 1
        buttonC.Text = "C"
        ' 
        ' buttonDelete
        ' 
        buttonDelete.BackColor = Color.Transparent
        buttonDelete.BorderRadius = 10
        buttonDelete.CustomizableEdges = CustomizableEdges47
        buttonDelete.DisabledState.BorderColor = Color.DarkGray
        buttonDelete.DisabledState.CustomBorderColor = Color.DarkGray
        buttonDelete.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        buttonDelete.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        buttonDelete.FillColor = Color.FromArgb(CByte(120), CByte(120), CByte(120))
        buttonDelete.Font = New Font("Segoe UI", 9F)
        buttonDelete.ForeColor = Color.White
        buttonDelete.Image = My.Resources.Resources.deletewhoite
        buttonDelete.ImageSize = New Size(35, 35)
        buttonDelete.Location = New Point(265, 20)
        buttonDelete.Name = "buttonDelete"
        buttonDelete.ShadowDecoration.CustomizableEdges = CustomizableEdges48
        buttonDelete.Size = New Size(79, 49)
        buttonDelete.TabIndex = 0
        ' 
        ' historyPanel
        ' 
        historyPanel.Controls.Add(RichTextBox1)
        historyPanel.Controls.Add(buttonClearHistory)
        historyPanel.Dock = DockStyle.Bottom
        historyPanel.Location = New Point(0, 551)
        historyPanel.Name = "historyPanel"
        historyPanel.Size = New Size(380, 5)
        historyPanel.TabIndex = 5
        ' 
        ' RichTextBox1
        ' 
        RichTextBox1.BackColor = Color.FromArgb(CByte(32), CByte(32), CByte(32))
        RichTextBox1.BorderStyle = BorderStyle.None
        RichTextBox1.Dock = DockStyle.Fill
        RichTextBox1.Font = New Font("Tahoma", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RichTextBox1.ForeColor = Color.Silver
        RichTextBox1.Location = New Point(0, 0)
        RichTextBox1.Margin = New Padding(0)
        RichTextBox1.Name = "RichTextBox1"
        RichTextBox1.ReadOnly = True
        RichTextBox1.ScrollBars = RichTextBoxScrollBars.Vertical
        RichTextBox1.Size = New Size(380, 0)
        RichTextBox1.TabIndex = 4
        RichTextBox1.Text = ""
        ' 
        ' buttonClearHistory
        ' 
        buttonClearHistory.Cursor = Cursors.Hand
        buttonClearHistory.Dock = DockStyle.Bottom
        buttonClearHistory.FlatAppearance.BorderSize = 0
        buttonClearHistory.FlatStyle = FlatStyle.Flat
        buttonClearHistory.ForeColor = Color.White
        buttonClearHistory.IconChar = FontAwesome.Sharp.IconChar.TrashCan
        buttonClearHistory.IconColor = Color.White
        buttonClearHistory.IconFont = FontAwesome.Sharp.IconFont.Auto
        buttonClearHistory.IconSize = 28
        buttonClearHistory.Location = New Point(0, -40)
        buttonClearHistory.Name = "buttonClearHistory"
        buttonClearHistory.Size = New Size(380, 45)
        buttonClearHistory.TabIndex = 3
        buttonClearHistory.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(32), CByte(32), CByte(32))
        ClientSize = New Size(380, 556)
        Controls.Add(historyPanel)
        Controls.Add(Guna2CustomGradientPanel1)
        Controls.Add(txtDisplay1)
        Controls.Add(txtDisplay2)
        Controls.Add(Guna2Panel1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Guna2Panel1.ResumeLayout(False)
        Guna2CustomGradientPanel1.ResumeLayout(False)
        historyPanel.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents buttonMinimize As FontAwesome.Sharp.IconButton
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents buttonHistory As FontAwesome.Sharp.IconButton
    Friend WithEvents txtDisplay2 As TextBox
    Friend WithEvents txtDisplay1 As TextBox
    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents buttonDelete As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonPercentage As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonCE As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonC As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button1overX As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonDivision As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button9 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonSquared As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonSquareRoot As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button6 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button7 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button8 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonAddition As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonSubtraction As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonMultiplication As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonEquals As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonThousand As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents button0 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents buttonDecimal As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents historyPanel As Panel
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents buttonClearHistory As FontAwesome.Sharp.IconButton
    Friend WithEvents Label1 As Label
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
End Class
