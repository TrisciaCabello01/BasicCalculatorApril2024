﻿Imports System.Runtime.InteropServices
Imports Guna.UI2.WinForms

Public Class Form1
    <DllImport("user32.dll", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub

    <DllImport("user32.dll", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(hWnd As IntPtr, wMsg As Integer, wParam As Integer, lParam As Integer)
    End Sub

    Dim result As Double = 0
    Dim operation As String = String.Empty
    Dim enterValue As Boolean = False

    Private Sub Panel1_MouseDown(sender As Object, e As MouseEventArgs) Handles Panel1.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        Application.Exit()
    End Sub

    Private Sub buttonNum_Click(sender As Object, e As EventArgs) Handles _
        button0.MouseDown, button1.MouseDown, button2.MouseDown, button3.MouseDown,
        button4.MouseDown, button5.MouseDown, button6.MouseDown, button7.MouseDown,
        button8.MouseDown, button9.MouseDown, buttonDecimal.MouseDown

        Dim button As Guna2Button = DirectCast(sender, Guna2Button)

        If txtDisplay1.Text = "0" OrElse enterValue Then
            txtDisplay1.Text = String.Empty
        End If
        enterValue = False

        If button.Text = "." Then
            If Not txtDisplay1.Text.Contains(".") Then
                txtDisplay1.Text &= button.Text
            End If
        Else
            txtDisplay1.Text &= button.Text
        End If
    End Sub

    Private Sub buttonMathOperation_MouseDown(sender As Object, e As MouseEventArgs) Handles _
        buttonAddition.MouseDown, buttonSubtraction.MouseDown,
        buttonMultiplication.MouseDown, buttonDivision.MouseDown

        Dim button As Guna2Button = DirectCast(sender, Guna2Button)
        PerformOperation(button.Text)
    End Sub

    Private Sub buttonEquals_Click(sender As Object, e As EventArgs) Handles buttonEquals.Click
        If Not String.IsNullOrEmpty(operation) AndAlso txtDisplay1.Text <> String.Empty Then
            Dim secNum As Double = Double.Parse(txtDisplay1.Text)
            Dim operationResult As Double

            Select Case operation
                Case "+"
                    operationResult = result + secNum
                Case "-"
                    operationResult = result - secNum
                Case "*"
                    operationResult = result * secNum
                Case "/"
                    If secNum <> 0 Then
                        operationResult = result / secNum
                    Else
                        txtDisplay1.Text = "Error"
                        Return
                    End If
            End Select

            txtDisplay1.Text = operationResult.ToString()
            txtDisplay2.Text = $"{result} {operation} {secNum} = {operationResult}"
            enterValue = True ' Allow chaining of operations

            Dim historyEntry As String = $"{result} {operation} {secNum} = {operationResult}"
            RichTextBox1.AppendText(historyEntry & Environment.NewLine)

            result = operationResult
            operation = String.Empty ' Reset operation for new calculations
        End If
    End Sub

    Private Sub PerformOperation(op As String)
        If Not String.IsNullOrEmpty(operation) AndAlso Not enterValue Then
            ' Evaluate previous operation
            buttonEquals.PerformClick()
        End If

        operation = op
        result = Double.Parse(txtDisplay1.Text)
        txtDisplay2.Text = $"{result} {operation}"
        enterValue = True
    End Sub

    Private Sub buttonHistory_Click(sender As Object, e As EventArgs) Handles buttonHistory.Click
        If historyPanel.Size.Height = 5 Then
            historyPanel.Size = New Size(historyPanel.Size.Width, 400) ' Expand historyPanel
        Else
            historyPanel.Size = New Size(historyPanel.Size.Width, 5) ' Shrink historyPanel
        End If
    End Sub

    Private Sub buttonClearHistory_Click(sender As Object, e As EventArgs) Handles buttonClearHistory.Click
        RichTextBox1.Clear()
    End Sub

    Private Sub buttonDelete_Click(sender As Object, e As EventArgs) Handles buttonDelete.Click
        If txtDisplay1.Text.Length > 0 Then
            txtDisplay1.Text = txtDisplay1.Text.Remove(txtDisplay1.Text.Length - 1, 1)
        End If
    End Sub

    Private Sub buttonC_Click(sender As Object, e As EventArgs) Handles buttonC.Click
        ' Clear the display
        txtDisplay1.Text = "0"
        enterValue = False
    End Sub

    Private Sub buttonCE_Click(sender As Object, e As EventArgs) Handles buttonCE.Click
        ' Clear the display and reset calculator state
        txtDisplay1.Text = "0"
        txtDisplay2.Text = String.Empty
        result = 0
        operation = String.Empty
        enterValue = False
    End Sub

    Private Sub buttonPercentage_Click(sender As Object, e As EventArgs) Handles buttonPercentage.Click
        If Double.TryParse(txtDisplay1.Text, Nothing) Then
            Dim value As Double = Double.Parse(txtDisplay1.Text)
            txtDisplay1.Text = (value / 100).ToString()
        End If
    End Sub

    Private Sub button1overX_Click(sender As Object, e As EventArgs) Handles button1overX.Click
        If Double.TryParse(txtDisplay1.Text, Nothing) Then
            Dim value As Double = Double.Parse(txtDisplay1.Text)
            txtDisplay1.Text = (1 / value).ToString()
        End If
    End Sub

    Private Sub buttonSquared_Click(sender As Object, e As EventArgs) Handles buttonSquared.Click
        If Double.TryParse(txtDisplay1.Text, Nothing) Then
            Dim value As Double = Double.Parse(txtDisplay1.Text)
            txtDisplay1.Text = (value * value).ToString()
        End If
    End Sub

    Private Sub buttonSquareRoot_Click(sender As Object, e As EventArgs) Handles buttonSquareRoot.Click
        If Double.TryParse(txtDisplay1.Text, Nothing) Then
            Dim value As Double = Double.Parse(txtDisplay1.Text)
            If value >= 0 Then
                txtDisplay1.Text = Math.Sqrt(value).ToString()
            Else
                txtDisplay1.Text = "Invalid Input"
            End If
        End If
    End Sub

    Private Sub buttonThousand_Click(sender As Object, e As EventArgs) Handles buttonThousand.Click
        If txtDisplay1.Text.Contains("...") Then
            txtDisplay1.Text = txtDisplay1.Text.Replace("...", "")
        Else
            Dim value As Double
            If Double.TryParse(txtDisplay1.Text, value) Then
                txtDisplay1.Text = String.Format("{0:N0}", value) ' N0 format adds commas for thousands
            End If
        End If
    End Sub

    Private Sub buttonMinimize_Click(sender As Object, e As EventArgs) Handles buttonMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Label1.ForeColor = GetRandomColor()
    End Sub
    Private Function GetRandomColor() As Color
        Dim rand As New Random()
        Return Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256))
    End Function
End Class
